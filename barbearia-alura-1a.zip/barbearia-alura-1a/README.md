# Barbearia Alura 1A

A Pen created on CodePen.io. Original URL: [https://codepen.io/thaycida8000/pen/xxYvXEj](https://codepen.io/thaycida8000/pen/xxYvXEj).

